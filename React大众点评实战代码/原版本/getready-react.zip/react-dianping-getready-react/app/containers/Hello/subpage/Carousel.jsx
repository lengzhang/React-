import React from 'react'

class Carousel extends React.Component {
    render() {
        return (
             <p>轮播图</p>
        )
    }
}

export default Carousel