import React from 'react'

class Recommend extends React.Component {
    render() {
        return (
             <p>推荐</p>
        )
    }
}

export default Recommend