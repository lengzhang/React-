# react-simple-o2o-demo

商户详情页面，文档参见[这里](./docs/README.md)