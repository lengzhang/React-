# react-simple-o2o-demo

介绍 Redux，详情参考[这里](./docs/README.md)